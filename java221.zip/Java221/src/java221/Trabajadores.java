package java221;

public interface Trabajadores {

    double bonusBase = 1500;
    double estableceBonus(double gratificacion);
    
    
}
