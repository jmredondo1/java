
package java221;

public interface Jefes extends Trabajadores{
    // No es necesario poner public y abstract porque ya lo asume
    // public abstract String tomarDecision (String td);
    String tomarDecision (String td);
}
